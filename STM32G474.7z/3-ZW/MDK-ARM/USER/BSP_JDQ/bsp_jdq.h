#ifndef __bsp_jdq_H
#define	__bsp_jdq_H


#include "main.h"

#define  RELAY_GPIO_CLK() 	  __HAL_RCC_GPIOB_CLK_ENABLE() 	
#define  RELAY_GPIO_PORT    	GPIOB	


#define RELAY1_GPIO_PIN		    GPIO_PIN_12        	              
#define RELAY2_GPIO_PIN		    GPIO_PIN_13		              
#define RELAY3_GPIO_PIN		    GPIO_PIN_14	              
#define RELAY4_GPIO_PIN		    GPIO_PIN_15

/* ֱ�Ӳ����Ĵ����ķ�������IO */
#define	digitalHi(p,i)		 {p->BSRR=i;}	 //���Ϊ�ߵ�ƽ		
#define digitalLo(p,i)		 {p->BRR=i;}	 //����͵�ƽ
#define digitalToggle(p,i) {p->ODR ^=i;} //�����ת״̬


/* �������IO�ĺ� */
#define RELAY1_TOGGLE		 digitalToggle(RELAY_GPIO_PORT,RELAY1_GPIO_PIN)
#define RELAY1_ON		      digitalHi(RELAY_GPIO_PORT,RELAY1_GPIO_PIN)
#define RELAY1_OFF			   digitalLo(RELAY_GPIO_PORT,RELAY1_GPIO_PIN)

#define RELAY2_TOGGLE		 digitalToggle(RELAY_GPIO_PORT,RELAY2_GPIO_PIN)
#define RELAY2_ON		   digitalHi(RELAY_GPIO_PORT,RELAY2_GPIO_PIN)
#define RELAY2_OFF			   digitalLo(RELAY_GPIO_PORT,RELAY2_GPIO_PIN)

#define RELAY3_TOGGLE		 digitalToggle(RELAY_GPIO_PORT,RELAY3_GPIO_PIN)
#define RELAY3_ON		   digitalHi(RELAY_GPIO_PORT,RELAY3_GPIO_PIN)
#define RELAY3_OFF			   digitalLo(RELAY_GPIO_PORT,RELAY3_GPIO_PIN)

#define RELAY4_TOGGLE		 digitalToggle(RELAY_GPIO_PORT,RELAY4_GPIO_PIN)
#define RELAY4_ON		   digitalHi(RELAY_GPIO_PORT,RELAY4_GPIO_PIN)
#define RELAY4_OFF			   digitalLo(RELAY_GPIO_PORT,RELAY4_GPIO_PIN)

void RELAY_GPIO_Config(void);

#endif /* __RELAY_H */
