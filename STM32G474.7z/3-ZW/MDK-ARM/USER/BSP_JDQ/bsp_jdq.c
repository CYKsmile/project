#include "bsp_jdq.h"   


void RELAY_GPIO_Config(void)
{		

		GPIO_InitTypeDef GPIO_InitStructure = {0};
		RELAY_GPIO_CLK(); 
		
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);
		
		GPIO_InitStructure.Pin = RELAY1_GPIO_PIN|RELAY2_GPIO_PIN|RELAY3_GPIO_PIN|RELAY4_GPIO_PIN;		
		GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStructure.Pull = GPIO_NOPULL;	
		GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH; 
		HAL_GPIO_Init(RELAY_GPIO_PORT, &GPIO_InitStructure);
}




